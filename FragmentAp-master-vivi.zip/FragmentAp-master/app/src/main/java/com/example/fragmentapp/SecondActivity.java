package com.example.fragmentapp;

import android.app.Activity;

public class SecondActivity extends Activity {
}
